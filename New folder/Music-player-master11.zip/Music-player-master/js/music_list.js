let musicList = [
    {
        name: "Rise up",
        artist: "TheFatRat",
        img: "img/Rise_up.png",
        src: "audio/TheFatRat-Rise_Up.mp3",
        love: false,
    },
    {
        name: "Fairytale",
        artist: "Alexander Rybak",
        img: "img/fairytale.jpg",
        src: "audio/Alexander_Rybak-Fairytale.mp3",
        love: false,
    },
    {
        name: "Impossible",
        artist: "James Arthur",
        img: "img/impossible.jpg",
        src: "audio/James_Arthur-Impossible.mp3",
        love: false,
    },
    {
        name: "Landscape",
        artist: "Jarico",
        img: "img/landscape.jpg",
        src: "audio/Jarico-Landscape.mp3",
        love: false,
    },
    {
        name: "Diamonds",
        artist: "Rihanna",
        img: "img/diamonds.jpg",
        src: "audio/Rihanna-diamonds.mp3",
        love: false,
    },
];
