<p align="center">
    <h1>Welcome to my Music player</h1>
</p>

<p align="center">
    <img src="https://img.shields.io/github/languages/top/uzcoin404/Music-player?style=flat" />
    <img src="https://img.shields.io/github/repo-size/uzcoin404/Music-player?style=flat" />
    <img src="https://img.shields.io/github/downloads/uzcoin404/Music-player/total" />
    <img src="https://img.shields.io/github/languages/count/uzcoin404/Music-player?style=flat" />
    <img src="https://img.shields.io/badge/-HTML-orange?style=flat" />
    <img src="https://img.shields.io/badge/-CSS-blue?style=flat">
    <img src="https://img.shields.io/badge/-JavaScript-yellow?style=flat">
    <img src="https://img.shields.io/github/issues/uzcoin404/Music-player?style=flat" />
    <img src="https://img.shields.io/github/issues-pr/uzcoin404/Music-player?style=flat" />
    <img src="https://img.shields.io/github/commit-activity/w/uzcoin404/Music-player?style=flat" />
    <img src="https://img.shields.io/github/contributors/uzcoin404/Music-player?style=flat" />
    <img src="https://img.shields.io/github/discussions/uzcoin404/Music-player?style=flat" />
    <img src="https://img.shields.io/badge/Star-Please%20Star%20it-green?style=flat" />
</p>

<img align="center" src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif" alt="javascript" width="100%"/>

<h3 style="font-size: 32px;">Please Follow me on</h3>
<p align="center">
    <a href="https://t.me/MrUzcoin" target="_blank"><img src="https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white"/></a>
    <a href="https://www.facebook.com/MrUzcoin/" target="_blank"><img src="https://img.shields.io/badge/Facebook-1778F2.svg?style=for-the-badge&logo=Facebook&logoColor=white"/></a>
    <a href="https://www.instagram.com/mruzcoin/" target="_blank"><img src="https://img.shields.io/badge/Instagram-%23E4405F.svg?style=for-the-badge&logo=Instagram&logoColor=white"/></a>
    <a href="https://twitter.com/suyunbe" target="_blank"><img src="https://img.shields.io/badge/Twitter-1DA1F2.svg?style=for-the-badge&logo=Twitter&logoColor=white"/></a>
    <a href="https://www.linkedin.com/in/suyunbek/" target="_blank"><img src="https://img.shields.io/badge/Linkedin-0072b1.svg?style=for-the-badge&logo=Linkedin&logoColor=white"/></a>
</p>

<img align="center" src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif" alt="javascript" width="100%"/>

<h3 style="font-size: 32px;">Hire me on</h3>
<p align="center">
    <a href="https://www.fiverr.com/uzcoin" target="_blank"><img src="https://img.shields.io/badge/Fiverr-00b22d?style=for-the-badge&logo=Fiverr&logoColor=white"/></a>
    <a href="https://www.linkedin.com/in/suyunbek/" target="_blank"><img src="https://img.shields.io/badge/Linkedin-0072b1.svg?style=for-the-badge&logo=Linkedin&logoColor=white"/></a>
    <a href="https://www.upwork.com/freelancers/~017f6ada468d8c4819" target="_blank"><img src="https://img.shields.io/badge/Upwork-385925.svg?style=for-the-badge&logo=Upwork&logoColor=white"/></a>
</p>
    
<p align="center">
    <img src="https://img.shields.io/github/followers/uzcoin404?style=social">
    <img src="https://img.shields.io/github/stars/uzcoin404?style=social">
    <img src="https://img.shields.io/github/forks/uzcoin404/404-pages?style=social">
    <img src="https://img.shields.io/github/watchers/uzcoin404/404-pages?style=social">
    <img src="https://komarev.com/ghpvc/?username=uzcoin404&label=Profile%20views&color=ff69b4" alt="Uzcoin404" />
</p>

<img align="center" src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif" alt="javascript" width="100%"/>

Please star a Repository and Share it
<p>Thanks</p>
